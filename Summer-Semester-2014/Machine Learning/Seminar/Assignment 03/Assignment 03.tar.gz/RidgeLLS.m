function W=RidgeLLS(X,Y,lambda)
[n D]=size(X);
W=inv(X'*X+n*lambda*eye(D))*(X'*Y);