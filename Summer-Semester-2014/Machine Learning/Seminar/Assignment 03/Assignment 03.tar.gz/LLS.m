function W=LLS(X,Y)
W=inv(X'*X)*(X'*Y);